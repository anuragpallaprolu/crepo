#include <stdio.h>
#include "SDL/SDL.h"

const int screen_width = 640;
const int screen_height = 480;
const int screen_bpp = 32;

SDL_Surface *message = NULL;
SDL_Surface *background = NULL;
SDL_Surface *screen = NULL;

SDL_Surface *load(char *file)
{
            SDL_Surface *loadedimage = NULL;
            SDL_Surface *opimage = NULL;
            loadedimage = SDL_LoadBMP(file);
            
            if(loadedimage!=NULL)
            {
                                 opimage = SDL_DisplayFormat(loadedimage);
                                 SDL_FreeSurface(loadedimage);
                                 }
            return opimage;
}

 
