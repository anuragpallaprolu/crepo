#include <stdio.h>
#include "SDL/SDL.h"
/*LAZY_FOO AND LYNCH-ENVY COMPUTER CORP. */

main(int argc, char* args[])
{
         SDL_Surface *hello = NULL;
         SDL_Surface *screen = NULL;
         
         SDL_Init(SDL_INIT_EVERYTHING);
         SDL_WM_SetCaption("Lynch Envy Computers", NULL);
         screen = SDL_SetVideoMode(640, 480, 32, SDL_SWSURFACE);
         hello = SDL_LoadBMP("Untitled.bmp");
         SDL_BlitSurface(hello, NULL, screen, NULL);
         SDL_Flip(screen);
         SDL_Delay(20000);
         SDL_FreeSurface(hello);
         SDL_Quit();
         return 0;
}
