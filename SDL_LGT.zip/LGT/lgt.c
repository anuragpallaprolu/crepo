#include <stdio.h>

//LYNCH GRAPHICS TOOLKIT
/*
NON SDL GRAPHER

DEPRECATED
!DO NOT USE!
*/

void point(int x, int y);
main()
{
      int i;
      for(i=0; i<=20; ++i)
      {
               printf("%d", 20-i);
               printf("\t|\n");
               }

      //for(i=0; i<=40; ++i)
      //{
      //         printf("|\n");
      //         }
      
      //printf("\t  *\n");
      point(3, 2);
      for(i=0; i<=20; ++i)
      {
               printf("- ");
      
               }
      printf("\n");
      printf("   \t");
      for(i=0; i<=20; ++i)
      {
               printf("%d ", i);
      
               }
      getch();
      }

void point(int x, int y)
{
     printf("\t");
     int i;
     for(i=20; i>=y; i--)
     {
               printf("\t");
               }
     printf("*");
                 
     for(i=1; i<=x; ++i)
     {
              printf("  ");
              }
     printf("*");
     
     printf("\n");
     
     
     
     }
