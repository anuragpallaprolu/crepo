Title: C.L.O.S.E - The Command Line Open Source Editor
Description: This program is a console based/command line text editor. It mainly displays a cursor. Main functions are OPEN, NEW, APPEND, FIND, SHOWDATE, SHOWTIME, HELP, QUIT.
It basically emulates the use of the fstream header file and also displays the importance of a delimiter.
User has to extract the zip file. Compile each c++ source code(preferably in Dev c++ or VC++) and finally compile CLOSE.cpp and run. 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=13170&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
